#define VER_MAJOR 1 
#define VER_MINOR 0 
#define VER_PATCH 0 
#define VER_BUILD 0 
#define VER_FILE "1.0.0.0" 
#define VER_PRODUCT "1.0.0" 
