// Assembly forms_mixed, Version 1.0.0.0

using namespace System::Reflection;
using namespace System::Runtime::CompilerServices;
using namespace System::Runtime::Versioning;
using namespace System::Runtime::InteropServices;
using namespace System::Diagnostics;

[assembly: AssemblyDescriptionAttribute("")];
[assembly: AssemblyConfigurationAttribute("")];
[assembly: AssemblyCompanyAttribute("")];
[assembly: RuntimeCompatibilityAttribute(WrapNonExceptionThrows=true)];
[assembly: AssemblyTrademarkAttribute("")];
[assembly: CompilationRelaxations(8)];
[assembly: AssemblyTitleAttribute("forms_mixed")];
[assembly: AssemblyProductAttribute("forms_mixed")];
[assembly: AssemblyCopyrightAttribute("Copyright ©  2014")];
[assembly: TargetFrameworkAttribute(".NETFramework,Version=v4.0", FrameworkDisplayName=".NET Framework 4")];
[assembly: ComVisibleAttribute(false)];
[assembly: GuidAttribute("31c4f344-7d2d-4fcc-8cf5-3c6d368ad136")];
[assembly: AssemblyFileVersionAttribute("1.0.0.0")];
