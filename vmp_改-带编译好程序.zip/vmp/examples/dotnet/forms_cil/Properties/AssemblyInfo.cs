using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: AssemblyTrademark("")]
[assembly: CompilationRelaxations(8)]
[assembly: AssemblyTitle("forms_cil")]
[assembly: AssemblyProduct("forms_cil")]
[assembly: AssemblyCopyright("Copyright �  2014")]
[assembly: ComVisible(false)]
[assembly: Guid("31c4f344-7d2d-4fcc-8cf5-3c6d368ad135")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Debuggable((DebuggableAttribute.DebuggingModes.DisableOptimizations | (DebuggableAttribute.DebuggingModes.EnableEditAndContinue | (DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.Default))))]